import numpy as np

A = np.loadtxt('levdata', skiprows=1)
array = np.array(A)



